
            package de.bsvrz.puk.config;
            public class PackageRuntimeInfo {
            public static String getLicence() { return "GPL";}
            public static String getRelease() { return "Kernsoftware 3.6.4";}
            public static String getVersion() { return "3.6.4";}
            public static String getRevision() { return "13360";}
            public static String getCompileTime() { return "10.04.2015 15:09:56";}
            public static String getDependsOnCompiled() { return "de.bsvrz.dav.daf, de.bsvrz.sys.funclib.dataSerializer, de.bsvrz.sys.funclib.communicationStreams, de.bsvrz.sys.funclib.commandLineArgs, de.bsvrz.sys.funclib.hexdump, de.bsvrz.sys.funclib.debug, de.bsvrz.sys.funclib.xmlSupport, de.bsvrz.sys.funclib.filelock, de.bsvrz.sys.funclib.crypt, de.bsvrz.sys.funclib.concurrent, de.bsvrz.sys.funclib.application";}
            public static String getDependsOnSource() { return "";}
            public static String getDependsOnLib() { return "";}
            public static String getJvmVersion() { return "1.6";}
            }
        