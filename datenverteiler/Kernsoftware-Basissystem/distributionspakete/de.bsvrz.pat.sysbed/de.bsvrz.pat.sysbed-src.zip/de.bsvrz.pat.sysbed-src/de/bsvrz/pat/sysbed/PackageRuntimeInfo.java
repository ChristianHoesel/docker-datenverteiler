
            package de.bsvrz.pat.sysbed;
            public class PackageRuntimeInfo {
            public static String getLicence() { return "GPL";}
            public static String getRelease() { return "Kernsoftware 3.7.2";}
            public static String getVersion() { return "3.7.2";}
            public static String getRevision() { return "5407469eb6a8f3af49ffb668c356e346264b7b9d";}
            public static String getCompileTime() { return "28.01.2016 16:56:09";}
            public static String getDependsOnCompiled() { return "de.bsvrz.sys.funclib.consoleProcessFrame, de.bsvrz.dav.daf, de.bsvrz.sys.funclib.dataSerializer, de.bsvrz.sys.funclib.communicationStreams, de.bsvrz.sys.funclib.application, de.bsvrz.sys.funclib.configObjectAcquisition, de.bsvrz.sys.funclib.debug, de.bsvrz.sys.funclib.commandLineArgs, de.bsvrz.sys.funclib.concurrent, de.bsvrz.pat.onlprot, de.bsvrz.pat.datgen, de.bsvrz.pat.sysprot, de.kappich.sys.funclib.json";}
            public static String getDependsOnSource() { return "";}
            public static String getDependsOnLib() { return "";}
            public static String getJvmVersion() { return "1.8";}
            }
        