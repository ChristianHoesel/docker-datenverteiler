
            package de.bsvrz.pat.onlprot;
            public class PackageRuntimeInfo {
            public static String getLicence() { return "GPL";}
            public static String getRelease() { return "Kernsoftware 3.6.4";}
            public static String getVersion() { return "3.6.4";}
            public static String getRevision() { return "13360";}
            public static String getCompileTime() { return "10.04.2015 15:07:15";}
            public static String getDependsOnCompiled() { return "de.bsvrz.dav.daf, de.bsvrz.sys.funclib.dataSerializer, de.bsvrz.sys.funclib.communicationStreams, de.bsvrz.sys.funclib.configObjectAcquisition, de.bsvrz.sys.funclib.debug, de.bsvrz.sys.funclib.commandLineArgs";}
            public static String getDependsOnSource() { return "";}
            public static String getDependsOnLib() { return "";}
            public static String getJvmVersion() { return "1.6";}
            }
        